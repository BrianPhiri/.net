﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circle_demo
{
    class Program
    {
        static void Main(string[] args) { 
            double r;
            Console.WriteLine("Circle Demo");
            Console.WriteLine("____________");
            Console.WriteLine("Please enter radius");
            r = Convert.ToDouble(Console.ReadLine());
            Circle cl = new Circle(r);
            double cl_Area = cl.Area();
            Console.WriteLine("Area: ");
            Console.WriteLine(cl_Area);
            Console.ReadLine();
        }
    }
}

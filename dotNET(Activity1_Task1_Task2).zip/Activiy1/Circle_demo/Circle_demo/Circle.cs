﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circle_demo
{
    class Circle
    {
        private double radius = 0.0;
        public Circle(double r) {
            radius = r;
        }
        public double Area() {
           
            return Math.PI * radius * radius;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simpleBankApplication_078699
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int choice;
            bankFunctions bk = new bankFunctions();
            Console.WriteLine("Hello, welcome to the Bank of Brian");
            Console.WriteLine("Please select an option");
            Console.WriteLine("What can I do for you?");
            Console.WriteLine("1. Create an Account");
            Console.WriteLine("2. Withdraw");
            Console.WriteLine("3. Deposit");
            Console.WriteLine("4. Check status");
            Console.WriteLine();
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice) {
                case 1:
                    bk.accountCreation();
                    break;
                case 2:
                    bk.withdrawal();
                    break;
                case 3:
                    bk.deposite();
                    break;
                case 4:
                    bk.statusCheck();
                    break;
                default:
                    Console.WriteLine("Sorry that option is not valid");
                    Console.ReadLine();
                    break;
            }
            Console.ReadKey();
        }
    }
}

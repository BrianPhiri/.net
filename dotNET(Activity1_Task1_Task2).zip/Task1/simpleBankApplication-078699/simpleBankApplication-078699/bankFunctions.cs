﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace simpleBankApplication_078699
{
    class bankFunctions
    {
        private string names, accountType, choice;
        private int account_number, yn;
        private double balance, amount;

        public void menu() {
            Console.WriteLine("would you like to make any other transactions? (y/n)");
            choice = Console.ReadLine();
            if (choice == "y")
            {
                Console.WriteLine("type 1 for Deposite and 2 for Withdraw");
                yn = Convert.ToInt32(Console.ReadLine());
                switch (yn)
                {
                    case 1:
                        this.deposite();
                        break;
                    case 2:
                        this.withdrawal();
                        break;
                    default:
                        Console.WriteLine("Sorry Invalid Choice.");
                        break;
                }
            }
            else {
                Console.WriteLine("Thank you for using Banking Brian...");
                Console.WriteLine("____________________________________");
                Console.WriteLine();
                Console.WriteLine("press any key to exit");
                Console.ReadLine();
            }
        }
        public bankFunctions() { }
        public void accountCreation() {
            Console.Clear();
            Console.WriteLine("Please enter user Information one line at a time");
            Console.WriteLine("Enter full names");
            names = Console.ReadLine();
            Console.WriteLine("Enter account type (eg. savings account)");
            accountType = Console.ReadLine();
            Console.WriteLine("You have completed the Account Creation ");
            Console.WriteLine("________________________________________");
            Console.WriteLine("");
            Console.WriteLine("New Account");
            Console.WriteLine("Account Holder name : "+ names);
            Console.WriteLine("Type of Account : " + accountType);
            this.deposite();  


        }
        public void withdrawal() {
            Console.Clear();
            Console.WriteLine("Hello welcome to the withdraw page");
            Console.WriteLine("__________________________________");
            Console.WriteLine("");
            Console.WriteLine("How much do you wish to withdrawal ");
            amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("____________________________________");
            Console.WriteLine("You wish to withdraw " + amount + ", is that right? (y/n)");
            choice = Console.ReadLine();
            if (choice == "y" || choice == "yes") {
                balance = balance - amount;
                Console.WriteLine("Withdraw succesful");
                this.statusCheck();
            } else {
                Console.WriteLine("Enter the information again?");
            }
        }
        public void deposite() {
            Console.Clear();
            Console.WriteLine("Hello welcome to the Deposite page");
            Console.WriteLine("__________________________________");
            Console.WriteLine("");
            Console.WriteLine("How much do you wish to Deposite ");
            amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("____________________________________");
            Console.WriteLine("You wish to withdraw " + amount + ", is that right? (y/n)");
            choice = Console.ReadLine();
            if (choice == "y" || choice == "yes")
            {
                balance = balance + amount;
                Console.WriteLine("Deposite succesful");
                this.statusCheck();

            }
            else {
                Console.WriteLine("Enter the information again?");
                this.deposite();
            }
        }
        public void statusCheck() {
            Console.Clear();
            Console.WriteLine("Hello " + names);
            Console.WriteLine();
            Console.WriteLine("You currently on the " + accountType + " plan.");
            Console.WriteLine("You currently have " + balance + " in your account.");

            Console.WriteLine("__________________________________________________");
            Console.ReadLine();
            this.menu();
        }
    }
}

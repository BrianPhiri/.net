﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace schools_registration_078699
{
    class CourseReg
    {
        private string courses;

        public CourseReg(string courses)
        {
            this.courses = courses;
        }

        public void splitCourse()
        {
            string[] course = courses.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            Console.WriteLine("Cousers registerd for : ");
            foreach (var item in course)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}

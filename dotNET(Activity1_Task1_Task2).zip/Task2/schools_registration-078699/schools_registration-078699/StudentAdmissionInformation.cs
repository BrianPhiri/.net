﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace schools_registration_078699
{
    public class StudentAdmissionInformation
    {

        private string fname;
        private string lname;
        private int age;
        private char gender;

        public StudentAdmissionInformation(string fname, string lname, int age, char gender) {
            this.fname = fname;
            this.lname = lname;
            this.age = age;
            this.gender = gender;
        }


        public void student() {
            Console.WriteLine("First Name : " + fname);
            Console.WriteLine("Last Name : " + lname);
            Console.WriteLine("Student Age : " + age);
            Console.WriteLine("Student Gender : " + gender);
        }
    }
}

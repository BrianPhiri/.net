﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace schools_registration_078699
{
    class FeePayment
    {
        private double fees;
        private double paid;

        public FeePayment(double fees, double paid)
        {
            this.fees = fees;
            this.paid = paid;
        }
        public void feePaied() {
            Console.WriteLine("Total Fees : "+ fees);
            Console.WriteLine("Ammount paid : " + paid);
            Console.WriteLine("Owes: " + (fees - paid));
        }
    }
}

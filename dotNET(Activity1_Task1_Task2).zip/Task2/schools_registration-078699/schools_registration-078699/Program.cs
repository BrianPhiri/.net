﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace schools_registration_078699
{
    class Program
    {

        static void Main(string[] args)
        {
            string fname, lname, courses;
            int age;
            double fees = 0, paid = 0;
            char gender;


            Console.WriteLine("Welcome to the Student Admissions Console Application");
            Console.WriteLine("_____________________________________________________");
            Console.WriteLine("Please Fill in the student Information");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Please enter student first name");
            fname = Console.ReadLine();
            Console.WriteLine("Please enter student last name");
            lname = Console.ReadLine();
            Console.WriteLine("Please enter student's age ");
            age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Please enter student's gender (m/f)");
            gender = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Please Enter the list of courses the student will take separating them with a comma");
            courses = Console.ReadLine();
            Console.WriteLine("Please indicate the total fees to be paid");
            fees = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please indicate the ammount paid");
            paid = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.WriteLine("__________________________________________________");
            Console.WriteLine("Added Student");
            Console.ReadLine();

            StudentAdmissionInformation std = new StudentAdmissionInformation(fname, lname, age, gender);
            CourseReg cs = new CourseReg(courses);
            FeePayment fee = new FeePayment(fees, paid);

            Console.Clear();
            Console.WriteLine("Student Information");
            Console.WriteLine("____________________");
            std.student();
            cs.splitCourse();
            fee.feePaied();


            Console.ReadLine();
        }

    }
}
